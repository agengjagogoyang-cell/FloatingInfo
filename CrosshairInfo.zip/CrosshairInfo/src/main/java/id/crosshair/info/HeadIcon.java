package id.crosshair.info;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.object.ObjectContents;
import org.bukkit.entity.Player;

/** Dipisah supaya class ini hanya dimuat kalau API-nya ada. */
final class HeadIcon {
    private HeadIcon() {}

    static boolean available() {
        try {
            Class.forName("net.kyori.adventure.text.object.ObjectContents");
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    static Component of(Player p) {
        return Component.object(ObjectContents.playerHead(p.getUniqueId()));
    }
}
