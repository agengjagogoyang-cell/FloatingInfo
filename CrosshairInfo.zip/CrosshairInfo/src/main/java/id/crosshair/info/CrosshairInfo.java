package id.crosshair.info;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.RayTraceResult;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class CrosshairInfo extends JavaPlugin implements Listener {

    private static final class State {
        BossBar bar;
        boolean shown;
        int miss;
        String lastKey = "";
    }

    private final Map<UUID, State> states = new HashMap<>();
    private Economy economy;

    private double range;
    private int graceTicks;
    private boolean headIcon;
    private TextColor cFrame, cName, cMoney, cDivider;
    private int taskId = -1;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        setupEconomy();
        load();
        Bukkit.getPluginManager().registerEvents(this, this);
    }

    @Override
    public void onDisable() {
        for (Player p : Bukkit.getOnlinePlayers()) hide(p, states.get(p.getUniqueId()));
        states.clear();
    }

    private void setupEconomy() {
        if (Bukkit.getPluginManager().getPlugin("Vault") == null) return;
        RegisteredServiceProvider<Economy> rsp =
                Bukkit.getServicesManager().getRegistration(Economy.class);
        if (rsp != null) economy = rsp.getProvider();
    }

    private void load() {
        reloadConfig();
        if (taskId != -1) Bukkit.getScheduler().cancelTask(taskId);
        range = getConfig().getDouble("range", 2.0);
        graceTicks = Math.max(1, getConfig().getInt("hide-grace-ticks", 4));
        int interval = Math.max(1, getConfig().getInt("check-interval-ticks", 2));
        headIcon = getConfig().getBoolean("use-head-icon", true) && HeadIcon.available();
        cFrame = color("colors.frame", "#3A3A4A");
        cName = color("colors.name", "#FFFFFF");
        cMoney = color("colors.money", "#FFD54F");
        cDivider = color("colors.divider", "#6B6B80");
        taskId = Bukkit.getScheduler().runTaskTimer(this, this::tick, 10L, interval).getTaskId();
    }

    private TextColor color(String path, String def) {
        TextColor c = TextColor.fromHexString(getConfig().getString(path, def));
        return c != null ? c : TextColor.fromHexString(def);
    }

    private void tick() {
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            if (!viewer.hasPermission("crosshairinfo.see")) continue;
            State st = states.computeIfAbsent(viewer.getUniqueId(), k -> new State());
            Player target = lookTarget(viewer);
            if (target == null) {
                if (st.shown && ++st.miss >= graceTicks) hide(viewer, st);
                continue;
            }
            st.miss = 0;
            String money = money(target);
            String key = target.getUniqueId() + "|" + target.getName() + "|" + money;
            if (key.equals(st.lastKey) && st.shown) continue; // tidak ada perubahan, tidak kirim paket
            st.lastKey = key;
            Component title = build(target, money);
            if (st.bar == null) {
                st.bar = BossBar.bossBar(title, 0f, BossBar.Color.WHITE, BossBar.Overlay.PROGRESS);
            } else {
                st.bar.name(title);
            }
            if (!st.shown) {
                viewer.showBossBar(st.bar);
                st.shown = true;
            }
        }
    }

    private Player lookTarget(Player v) {
        var eye = v.getEyeLocation();
        var dir = eye.getDirection();
        RayTraceResult hit = v.getWorld().rayTraceEntities(eye, dir, range, 0.1, e ->
                e instanceof Player p && !p.equals(v) && v.canSee(p)
                        && p.getGameMode() != GameMode.SPECTATOR && !p.isInvisible());
        if (hit == null || !(hit.getHitEntity() instanceof Player target)) return null;
        // jangan tampil menembus tembok
        RayTraceResult block = v.getWorld().rayTraceBlocks(eye, dir, range);
        if (block != null && block.getHitPosition() != null
                && block.getHitPosition().distanceSquared(eye.toVector())
                   < hit.getHitPosition().distanceSquared(eye.toVector())) return null;
        return target;
    }

    private String money(Player p) {
        if (economy == null) return "-";
        return compact(economy.getBalance(p));
    }

    private static String compact(double v) {
        String[] s = {"", "K", "M", "B", "T"};
        int i = 0;
        while (Math.abs(v) >= 1000 && i < s.length - 1) { v /= 1000; i++; }
        String n = (i == 0) ? String.format("%.0f", v) : String.format("%.1f", v).replace(",", ".");
        if (n.endsWith(".0")) n = n.substring(0, n.length() - 2);
        return n + s[i];
    }

    private Component build(Player t, String money) {
        Component icon = headIcon ? HeadIcon.of(t) : Component.text("\u263B", cName);
        return Component.text()
                .append(Component.text("\u25D6 ", cFrame))          // sisi kiri melengkung
                .append(icon)
                .append(Component.text(" " + t.getName(), cName))
                .append(Component.text("  \u2502  ", cDivider))
                .append(Component.text("$" + money, cMoney))
                .append(Component.text(" \u25D7", cFrame))          // sisi kanan melengkung
                .build();
    }

    private void hide(Player p, State st) {
        if (st == null) return;
        if (st.bar != null && st.shown) p.hideBossBar(st.bar);
        st.shown = false;
        st.miss = 0;
        st.lastKey = "";
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        states.remove(e.getPlayer().getUniqueId());
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!s.hasPermission("crosshairinfo.admin")) return true;
        load();
        s.sendMessage("CrosshairInfo config di-reload.");
        return true;
    }
}
